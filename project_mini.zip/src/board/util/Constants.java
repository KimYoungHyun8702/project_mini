package board.util;

public interface Constants {

	int BOARDS_PER_PAGE = 5;//한 페이지당 보여줄 item의 수.
	int PAGES_PER_PAGEGROUP = 3; //한 페이지 그룹당 묶을 페이지수.
}
